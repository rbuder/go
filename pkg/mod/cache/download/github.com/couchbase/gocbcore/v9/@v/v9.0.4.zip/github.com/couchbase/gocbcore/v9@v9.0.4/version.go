package gocbcore

// Version returns a string representation of the current SDK version.
func Version() string {
	return goCbCoreVersionStr
}
